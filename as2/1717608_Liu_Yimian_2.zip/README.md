## How to begin
Please execute the compilergcc.bat to compile.<br/>

Or you can install gcc manually and use the following command to compile.
````
$ g++ -O2 -o ex1 ex1/ex1.cpp
$ g++ -O2 -o ex2 ex2/main.cpp ex2/player.cpp ex2/container.cpp ex2/swordsman.cpp ex2/archer.cpp ex2/mage.cpp
````

## gcc Download url
**For windows**
https://yimian-setup.obs.myhwclouds.com/setup/tdm64-gcc-5.1.0-2.exe
