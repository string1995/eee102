## How to begin
Please execute the compilergcc.bat to compile.<br/>

Or you can install gcc manually and use the following command to compile.
````
$ g++ -O2 -o same_vec same_vec.cpp
$ g++ -O2 -o Fraction_test Fraction_test.cpp Fraction.h
````

## gcc Download url
**For windows**
https://yimian-setup.obs.myhwclouds.com/setup/tdm64-gcc-5.1.0-2.exe
